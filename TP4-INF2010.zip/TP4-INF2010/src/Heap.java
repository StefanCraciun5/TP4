import java.util.ArrayList;

public class Heap<AnyType extends Comparable<AnyType>> {
    boolean maxHeap;
    int currentSize = 0;
    public ArrayList<AnyType> array;

    public Heap() {
        this.maxHeap = true;
        this.array = new ArrayList<AnyType>();
    }

    public Heap(boolean bool) {
        this.maxHeap = bool;
    }

    public int parent(int index) {
        return index / 2;
    }

    public int left(int index) {
        return 2 * index;
    }

    public int right(int index) {
        return 2 * index + 1;
    }

    public AnyType getParent(int index) {
        return array.get(parent(index));
    }

    public AnyType getLeft(int index) {
        return array.get(left(index));
    }

    public AnyType getRight(int index) {
        return array.get(right(index));
    }

    public void swap(int index1, int index2) {
        AnyType tmp = array.get(index1);
        array.set(index1, array.get(index2));
        array.set(index2, tmp);
    }

    public void insert(AnyType x) {
        array.add(x);

        percolateUp(currentSize);
    }


    public AnyType deleteMin() {
        if (array.size() == 0)
            return null;

        AnyType minItem = findMin(array);
        array.set(1, array.get(currentSize--));
        //percolateDown(1);
        return minItem;
    }

    private AnyType findMin(ArrayList<AnyType> array) {
        AnyType min = array.get(1);
        for (int i = 1; i <= array.size(); i++) {
            if ((array.get(i)).compareTo(min) < 0) {
                min = array.get(i);
            }
        }
        return min;
    }

    /*
    private void percolateDown(int hole) {
        int child;
        AnyType tmp = array.get(hole);
        for (; hole * 2 <= currentSize; hole = child) {
            child = hole * 2; // Considérer fils de gauche
            if (child != currentSize && // Il y a deux fils
                    array.get(child + 1).compareTo(array.get(child)) < 0) // Et fils droit < fils gauche
                child++; //Considérer fils droit
            if (array.get(child).compareTo(tmp) < 0)// Fils considéré < élément à percoler
                array.set(hole, array.get(child)); // Remonter le fils courrent de un niveau
            else
                break; // Sortir de la boucle. L’élément à percoler sera inséré à position hole
        }
        array.set(hole, tmp); // Insérer l’élément à percoler à la position hole
    }
    */

    /*
    public void percolateDown(int index) {
        if maxHeap {

        }
        else {
            if ()
        }
    }
    */

    public void percolateUp(int index) {
        if (maxHeap) {
            int cmp = (array.get(index)).compareTo(getParent(index));
            if (index > 1 && cmp > 0) {
                swap(index, parent(index));
                percolateUp(parent(index));
            }
        }
        else {
            int cmp = (array.get(index)).compareTo(getParent(index));
            if (index > 1 && cmp < 0) {
                swap(index, parent(index));
                percolateUp(parent(index));
            }
        }
    }

    private void heapify() {
        for (int i = currentSize / 2; i > 0; i--) {}
            //percolateDown(i);
    }

}

/*

const bool isMaxHeap ) True;
ArrayList<AnyType> data;

Heap()   OK
Heap(data[])     Partie 2
Heap(bool)   OK
Heap(data[], bool)     Partie 2

parent(index) -> index   OK
left(index) -> index   OK
right(index) -> index   OK
getParent(index) -> AnyType   OK
getLeft(index)
getRight(index)

swap(index,index)   OK
heapify()   OK
percolateDown
percolateUp

push=insert
pop=delete   OK
sort     Partie 2

*/