package Maze;

public class Counter {
    public int totalNodesTraversed = 0;
    public int stackedNodes = 0;
    public int maxStackSize = 0;
}
