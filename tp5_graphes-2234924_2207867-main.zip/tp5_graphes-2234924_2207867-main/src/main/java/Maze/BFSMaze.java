package Maze;

import java.util.ArrayList;
import java.util.stream.Collectors;
import java.util.Queue;
import java.util.LinkedList;

/** TODO
 ** Implement BFS algorithm to solve the maze.
 */
public class BFSMaze {

    Point[][] mazePoint;
    ArrayList<ArrayList<Tile>> maze;


    public static int[][] findStartFinish(ArrayList<ArrayList<Tile>> maze) {

        int[][] pos = new int[1][1];
        int largeur = maze.get(0).size();
        pos[0][1] = 0;
        pos[1][1] = largeur - 1;

        for (int i = 0; i < maze.size(); i++) {
            if (maze.get(i).get(0) == Tile.Exit) {
                pos[0][0] = i;
            }
            if (maze.get(i).get(largeur - 1) == Tile.Exit) {
                pos[1][0] = i;
            }
        }
        return pos;
    }

    /** TODO
     * Returns the distance of the shortest path within the maze
     * @param maze 2D table representing the maze
     * @return Distance of the shortest path within the maze, null if not solvable
     */

    public static int[] getDroite(int[] point){
        int[] nouveau_point = new int[point.length];
        nouveau_point[0] = point[0];
        nouveau_point[1] = point[1] + 1;
        return nouveau_point;
    }
    public static int[] getGauche(int[] point){
        int[] nouveau_point = new int[point.length];
        nouveau_point[0] = point[0];
        nouveau_point[1] = point[1] - 1;
        return nouveau_point;
    }
    public static int[] getHaut(int[] point){
        int[] nouveau_point =new  int[point.length];
        nouveau_point[0] = point[0] - 1;
        nouveau_point[1] = point[1];
        return nouveau_point;
    }
    public static int[] getBas(int[] point){
        int[] nouveau_point =new  int[point.length];
        nouveau_point[0] = point[0] + 1;
        nouveau_point[1] = point[1];
        return nouveau_point;
    }

    public static Integer findPath(ArrayList<ArrayList<Tile>> maze) {
        Queue<int[]> q = new LinkedList<>();
        boolean[][] visites = new boolean[maze.size()][maze.get(0).size()];
        int[][] pointsSF = findStartFinish(maze);

        q.add(pointsSF[0]);
        visites[pointsSF[0][0]][pointsSF[0][1]] = true;

        while (!q.isEmpty()) {
            int[] pointAct = q.poll();
            // Point gauche
            if (pointAct[1] != 0 && maze.get(pointAct[0]).get(pointAct[1] - 1) == Tile.Floor && !(visites[pointAct[0]])[pointAct[1] - 1]) {
                visites[pointAct[0]][pointAct[1] - 1] = true;
                int[] pointGauche = new int[2];
                pointGauche[0] = pointAct[0];
                pointGauche[1] = pointAct[1] - 1;
                q.add(pointGauche);
            }
            // Point bas
             if (pointAct[0] != maze.size() - 1 && maze.get(pointAct[0] + 1).get(pointAct[1]) == Tile.Floor && !(visites[pointAct[0] + 1])[pointAct[1]]) {
                visites[pointAct[0] + 1][pointAct[1]] = true;
                int[] pointBas = new int[2];
                pointBas[0] = pointAct[0] + 1;
                pointBas[1] = pointAct[1] ;
                q.add(pointBas);
            }
            // Point droite
            if (pointAct[1] != maze.get(0).size()-1 && maze.get(pointAct[0]).get(pointAct[1] + 1) == Tile.Floor && !(visites[pointAct[0]])[pointAct[1] + 1]) {
                visites[pointAct[0]][pointAct[1] + 1] = true;
                int[] pointDroit = new int[2];
                pointDroit[0] = pointAct[0];
                pointDroit[1] = pointAct[1] + 1;
                q.add(pointDroit);
            }
            // Point haut
            if (pointAct[0] != 0 && maze.get(pointAct[0] - 1).get(pointAct[1]) == Tile.Floor && !(visites[pointAct[0] - 1])[pointAct[1]]) {
                visites[pointAct[0] -1][pointAct[1]] = true;
                int[] pointHaut = new int[2];
                pointHaut[0] = pointAct[0] -1;
                pointHaut[1] = pointAct[1];
                q.add(pointHaut);
            }
        }




        return 0;
    }

    public static void printMaze(ArrayList<ArrayList<Tile>> maze) {
        for (ArrayList<Tile> row : maze) {
            System.out.println(row.stream().map(String::valueOf).collect(Collectors.joining("")));
        }
    }
}
