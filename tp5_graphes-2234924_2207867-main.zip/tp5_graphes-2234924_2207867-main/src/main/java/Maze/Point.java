package Maze;

public class Point {
    int x;
    int y;
    Tile tile;
    public Point(int x, int y, Tile tile ) {
        this.x = x;
        this.y = y;
        this.tile = tile;
    }


}
