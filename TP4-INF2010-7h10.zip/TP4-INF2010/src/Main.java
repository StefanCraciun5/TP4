import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Monceau hp = new Monceau( true);
        MinHeap mhp = new MinHeap();


        hp.insert(13);
        hp.insert(21);
        hp.insert(16);
        hp.insert(24);
        hp.insert(31);
        hp.insert(19);
        hp.insert(68);
        hp.insert(65);
        hp.insert(26);
        hp.insert(32);
        hp.insert(14);

        mhp.insert(13);
        mhp.insert(21);
        mhp.insert(16);
        mhp.insert(24);
        mhp.insert(31);
        mhp.insert(19);
        mhp.insert(68);
        mhp.insert(65);
        mhp.insert(26);
        mhp.insert(32);
        mhp.insert(14);
        /*
        heap.insert(13);
        heap.insert(21);
        heap.insert(16);
        heap.insert(24);
        heap.insert(31);
        heap.insert(19);
        heap.insert(68);

        heap.insert(65);
        heap.insert(26);
        heap.insert(32);
        heap.insert(14);
*/

        System.out.println(Arrays.toString(mhp.heap.toArray()));
        mhp.deleteMin();
        System.out.println(Arrays.toString(mhp.heap.toArray()));
        System.out.println();
        System.out.println();
        System.out.println(Arrays.toString(hp.heap.toArray()));
        hp.deleteFirst();
        System.out.println(Arrays.toString(hp.heap.toArray()));

    }
}
