import java.util.ArrayList;
import java.lang.Double;


public class Monceau {

    boolean minHeap;

    private static int parent(int x) {
        return (x - 1) / 2;
    }

    private static int leftChild(int x) {
        return x * 2 + 1;
    }

    private static int rightChild(int x) {
        return x * 2 + 2;
    }

    /* Private Fields */
    public ArrayList<Integer> heap;

    /* Constructor */
    public Monceau() {
        this.heap = new ArrayList<Integer>();
    }

    public Monceau(boolean bl) {
        this.minHeap = bl;
        this.heap = new ArrayList<Integer>();
    }

    /* Private Methods */
    private int getParent(int x) {
        return this.heap.get(Monceau.parent(x));
    }

    private int getLeftChild(int x) {

        return this.heap.get(Monceau.leftChild(x));

    }

    private int getRightChild(int x) {

        return this.heap.get(Monceau.rightChild(x));

    }

    private void swap(int x1, int x2) {
        int tmp = this.heap.get(x1);
        this.heap.set(x1, this.heap.get(x2));
        this.heap.set(x2, tmp);
    }

    /* Public Methods */
    public void insert(int value) {
        if (!minHeap) {
            int x = this.heap.size();
            this.heap.add(value);

            while (this.getParent(x) < value) {
                int parent = Monceau.parent(x);
                this.swap(parent, x);
                x = parent;
            }
        } else {
            int x = this.heap.size();
            this.heap.add(value);

            while (this.getParent(x) > value) {
                int parent = Monceau.parent(x);
                this.swap(parent, x);
                x = parent;
            }
        }
    }

    public int deleteFirst() {
        int out = this.heap.get(0);


        int last = this.heap.remove(this.heap.size() - 1);
        int x = 0;
        this.heap.set(x, last);

        int left = this.getLeftChild(x);
        int right = this.getRightChild(x);
        //percDown(last, x, left, right);
        if (minHeap) {
            while (last > left || last > right) {
                int replacer;

                if (last > left && last > right)
                    replacer = (left < right)
                            ? Monceau.leftChild(x)
                            : Monceau.rightChild(x);
                else if (last > left)
                    replacer = Monceau.leftChild(x);
                else
                    replacer = Monceau.rightChild(x);

                this.swap(x, replacer);

                x = replacer;
                left = this.getLeftChild(x);
                right = this.getRightChild(x);
            }
        } else {
            //percDown(last, x, right, left);
            while (last < left || last < right) {
                int replacer;

                if (last < left && last < right)
                    replacer = (left > right)
                            ? Monceau.leftChild(x)
                            : Monceau.rightChild(x);
                else if (last < left)
                    replacer = Monceau.leftChild(x);
                else
                    replacer = Monceau.rightChild(x);

                this.swap(x, replacer);

                x = replacer;
                left = this.getLeftChild(x);
                right = this.getRightChild(x);
            }
        }


        return out;
    }

    /* Utility Methods */
    public void print() {
        int row = 1;
        int count = 0;

        for (int i : this.heap) {
            if (count == row) {
                System.out.println();
                count = 0;
                row++;
            }

            System.out.printf("%d ", i);
            count++;
        }
    }
}
