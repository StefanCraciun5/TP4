import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Main {
    public static void main(String[] args) {

        Monceau hp = new Monceau(false);

        int[] tab = {1,1,1,1,2,3,4,5,5,6,7,8,9,9,9};
        System.out.println(Arrays.toString(tab));

        hp.buildHeap(tab,tab.length,false);
        System.out.println(Arrays.toString(tab));

        System.out.println();
        System.out.println();

        int[] tabA = new int[25];
        for (int i = 0; i < tabA.length; i++) {
            Random rand = new Random();
            int r = rand.nextInt(100);
            tabA[i] = r;
        }
        int[] tabB = new int[25];
        for (int i = 0; i < tabA.length; i++) {
            Random rand = new Random();
            int r = rand.nextInt(100);
            tabB[i] = r;
        }
        int[] tabC = new int[25];
        for (int i = 0; i < tabA.length; i++) {
            Random rand = new Random();
            int r = rand.nextInt(100);
            tabC[i] = r;
        }

        Monceau hpA = new Monceau(false);
        Monceau hpB = new Monceau(false);
        Monceau hpC = new Monceau(false);

        System.out.println(Arrays.toString(tabA));
        System.out.println(Arrays.toString(tabB));
        System.out.println(Arrays.toString(tabC));

        System.out.println();

        hpA.heapSort(tabA, 25, false);
        hpB.heapSort(tabB, 25, false);
        hpC.heapSort(tabC, 25, false);

        System.out.println();

        System.out.println(Arrays.toString(tabA));
        System.out.println(Arrays.toString(tabB));
        System.out.println(Arrays.toString(tabC));
    }
}
