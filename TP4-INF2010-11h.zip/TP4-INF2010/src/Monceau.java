import java.util.ArrayList;
import java.lang.Double;

class Monceau {
    boolean minHeap;

    /* Static Methods */
    private static int parent(int x) {
        return (x - 1) / 2;
    }

    private static int leftChild(int x) {
        return x * 2 + 1;
    }

    private static int rightChild(int x) {
        return x * 2 + 2;
    }

    /* Private Fields */
    public ArrayList<Integer> heap;

    /* Constructor */
    public Monceau() {
        this.heap = new ArrayList<Integer>();
    }

    public Monceau(boolean bl) {
        minHeap = bl;
        this.heap = new ArrayList<Integer>();
    }

    /* Private Methods */
    private int getParent(int x) {
        return this.heap.get(parent(x));
    }

    private int getLeftChild(int x) {
        try {
            return this.heap.get(leftChild(x));
        } catch (Exception e) {
            return (int) Double.POSITIVE_INFINITY;
        }
    }

    private int getRightChild(int x) {
        try {
            return this.heap.get(rightChild(x));
        } catch (Exception e) {
            return (int) Double.POSITIVE_INFINITY;
        }
    }

    private void swap(int x1, int x2) {
        int tmp = this.heap.get(x1);
        this.heap.set(x1, this.heap.get(x2));
        this.heap.set(x2, tmp);
    }


    /* Public Methods */
    public void insert(int value) {
        if (!minHeap) {
            int x = this.heap.size();
            this.heap.add(value);

            while (this.getParent(x) < value) {
                int parent = Monceau.parent(x);
                this.swap(parent, x);
                x = parent;
            }
        } else {
            int x = this.heap.size();
            this.heap.add(value);

            while (this.getParent(x) > value) {
                int parent = Monceau.parent(x);
                this.swap(parent, x);
                x = parent;
            }
        }
    }

    public int deleteFirst() {
        int out = this.heap.get(0);


        int last = this.heap.remove(this.heap.size() - 1);
        int x = 0;
        this.heap.set(x, last);

        int left = this.getLeftChild(x);
        int right = this.getRightChild(x);

        if (minHeap) {
            percDown(last, x, left, right);
        } else {
            percDown(last, x, right, last);
        }
        return out;
    }

    private void percDown(int last, int x, int left, int right) {
        while (last > left || last > right) {
            int replacer;

            if (last > left && last > right)
                replacer = (left < right)
                        ? leftChild(x)
                        : rightChild(x);
            else if (last > left)
                replacer = leftChild(x);
            else
                replacer = rightChild(x);

            this.swap(x, replacer);

            x = replacer;
            left = this.getLeftChild(x);
            right = this.getRightChild(x);
        }
    }


    void heapSort(int arr[], int N, boolean minHeap) {

        buildHeap(arr, N, minHeap);

        for (int i = N - 1; i > 0; i--) {
            int temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;
            heapify(arr, i, 0, minHeap);
        }
    }

    static void heapify(int array[], int size, int i, boolean minHeap) {
        int largest = i;    // Initialize current node as largest
        int left = 2 * i + 1;   // position of left child in array = 2*i + 1
        int right = 2 * i + 2;   // position of right child in array = 2*i + 2

        if (minHeap) {
            if (left < size && array[left] < array[largest])  // If left child is larger than root
                largest = left;

            if (right < size && array[right] < array[largest]) // If right child is larger than largest so far
                largest = right;
        } else {
            if (left < size && array[left] > array[largest])  // If left child is larger than root
                largest = left;

            if (right < size && array[right] > array[largest]) // If right child is larger than largest so far
                largest = right;
        }
        if (largest != i) {         // If largest is not root swap it
            int swap = array[i];
            array[i] = array[largest];
            array[largest] = swap;

            heapify(array, size, largest, minHeap); // Recursively heapify the sub-tree
        }
    }

    static void buildHeap(int arr[], int n, boolean minHeap) {
        int startIdx = (n / 2) - 1; // Index of last non-leaf node
        for (int i = startIdx; i >= 0; i--) {
            heapify(arr, n, i, minHeap);
        }
    }
}
